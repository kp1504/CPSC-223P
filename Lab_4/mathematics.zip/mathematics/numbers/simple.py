#By Kshitij Pingle
#simple.py
#This file is a part of numbers subpackage
#This file and the mathematics package are a part of Lab 4 for CPSC 223P


def addition(*, left, right):
    return (left + right)


def subtraction(*, left, right):
    return (left - right)


def multiplication(*, left, right):
    return (left * right)


def division(*, left, right):
    return (left / right)

#End of simple.py
