#By Kshitij Pingle
#cube.py
#This file is a part of geometry subpackage
#This file and the mathematics package are a part of Lab 4 for CPSC 223P


def surface_area(*, side):
    return (side * side * 6)


def volume(*, side):
    return (side * side * side)

#End of cube.py
