#Made by Kshitij Pingle
#This file is a part of mathematic package
#This file and the mathematics package were made for Lab 4 of CPSC 223P
#__init__.py


__all__ = ["whoami"]
