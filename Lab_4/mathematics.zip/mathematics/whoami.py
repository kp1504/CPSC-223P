#By Kshitij Pingle
#whoami.py
#This file is a part of mathematics package
#This file and the mathematics package are a part of Lab 4 for CPSC 223P


def getname():
    return __name__

