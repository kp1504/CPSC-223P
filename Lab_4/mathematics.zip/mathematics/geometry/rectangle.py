#By Kshitij Pingle
#rectangle.py
#This file is a part of geometry subpackage
#This file and the mathematics package are a part of Lab 4 for CPSC 223P


def perimeter(*, length, width):
    return ((2 * length) + (2 * width))


def area(*, length, width):
    return (length * width)

#End of rectangle.py
