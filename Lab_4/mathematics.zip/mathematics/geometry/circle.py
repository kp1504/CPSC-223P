#By Kshitij Pingle
#circle.py
#This file is a part of geometry subpackage
#This file and the mathematics package are a part of Lab 4 for CPSC 223P

import math

def circumference(*, radius):
    return (2 * math.pi * radius)


def area(*, radius):
    return (math.pi * radius * radius)

#End of circle.py
